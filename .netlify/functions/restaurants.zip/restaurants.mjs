
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/restaurants.mjs
var restaurants_default = async () => {
  try {
    const response = await fetch(
      "https://namastedev.com/api/v1/listRestaurants"
    );
    console.log("NamasteDev status:", response.status);
    if (!response.ok) {
      const errorBody = await response.text();
      console.error("NamasteDev response:", errorBody);
      return Response.json(
        {
          error: "Restaurant API request failed",
          upstreamStatus: response.status,
          details: errorBody.slice(0, 500)
        },
        { status: 502 }
      );
    }
    const data = await response.json();
    return Response.json(data);
  } catch (error) {
    console.error("Function error:", error);
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
};
export {
  restaurants_default as default
};
